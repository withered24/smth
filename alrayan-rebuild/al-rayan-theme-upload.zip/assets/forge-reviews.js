(function () {
  if (customElements.get("forge-reviews")) return;

  const BODY_MIN_CHARS = 10;

  const I18N_DEFAULTS = {
    addReview: "Add a review",
    noReviewsYet: "Be the first to leave a review.",
    dialogTitle: "Tell us about your review",
    nameLabel: "Name",
    namePlaceholder: "Enter your name...",
    emailLabel: "Email",
    emailPlaceholder: "Enter your email...",
    feedbackLabel: "Feedback",
    feedbackPlaceholder: "Write your feedback...",
    minCharsHint:
      "Add at least {{ count }} more characters to share your experience.",
    photosHint: "(Accepts .gif, .jpg, .png and 5MB limit)",
    photosSelected: "{{ count }} photos selected",
    cancel: "Cancel",
    submit: "Submit",
    submitThanks: "Thanks! Your review was submitted and is pending approval.",
    genericError: "Something went wrong while submitting. Please try again.",
    yourRatingLabel: "Your rating",
    starsAriaLabel: "{{ count }} stars",
    paginationNavLabel: "Reviews pagination",
    paginationPrevious: "Previous",
    paginationNext: "Next",
    paginationGotoPage: "Go to page {{ page }}",
    featuredLabel: "Customer reviews",
    featuredSlideLabel: "Review {{ current }} of {{ total }}",
    summaryHeading: "What customers are saying",
    summaryProsHeading: "Liked",
    summaryConsHeading: "To consider",
    summaryAiBadge: "AI generated summary",
    ratingLabels: {
      1: "Poor",
      2: "Fair",
      3: "Good",
      4: "Very good",
      5: "Excellent",
    },
    submitErrors: {
      name_required: "Please enter your name.",
      email_required: "Please enter your email address.",
      email_invalid:
        "That doesn't look like a valid email. Check for typos and try again.",
      body_required: "Please write a short review before submitting.",
      body_too_short:
        "Your review is a bit short — please add a few more details about your experience.",
      body_too_long:
        "Your review is too long. Please keep it under 5,000 characters.",
      invalid_rating: "Please select a star rating from 1 to 5.",
      invalid_input:
        "Some required fields need attention. Please check the form and try again.",
      invalid_shop:
        "We couldn't submit your review right now. Please try again in a moment.",
      invalid_product:
        "We couldn't find this product. Please refresh the page and try again.",
      too_many_photos:
        "You've attached too many photos. Please remove some and try again.",
      photo_invalid_type:
        "One photo isn't a supported format. Please use JPG, PNG, or GIF.",
      photo_too_large: "One photo is too large. Each photo must be under 5 MB.",
    },
  };

  function humanizeSubmitError(i18n, code) {
    const map = i18n?.submitErrors || {};
    if (code && map[code]) return map[code];
    return i18n?.genericError || "Something went wrong.";
  }

  function fmt(template, vars) {
    let out = String(template ?? "");
    if (!vars) return out;
    for (const [k, v] of Object.entries(vars)) {
      out = out
        .split(`{{ ${k} }}`)
        .join(String(v))
        .split(`{{${k}}}`)
        .join(String(v));
    }
    return out;
  }

  // SECURITY: keep escapeHtml in sync with server-side review text validation.
  function escapeHtml(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;")
      .replace(/`/g, "&#96;")
      .replace(/=/g, "&#61;");
  }

  function starsHtml(rating, color) {
    const full = Math.floor(rating);
    const half = rating - full >= 0.5 ? 1 : 0;
    let html = "";
    for (let i = 0; i < 5; i++) {
      const filled = i < full || (i === full && half);
      html += `<span style="color:${filled ? color : "#ddd"}">★</span>`;
    }
    return html;
  }

  function featuredStarsHtml(rating, fillColor, emptyColor) {
    const full = Math.max(0, Math.min(5, Math.round(Number(rating) || 0)));
    let html = "";
    for (let i = 0; i < 5; i++) {
      const color = i < full ? fillColor : emptyColor;
      html += `<span class="forge-reviews__featured-star" style="color:${color}" aria-hidden="true"><svg viewBox="0 0 24 24" width="1em" height="1em" focusable="false"><path fill="currentColor" d="M12 17.27 18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg></span>`;
    }
    return html;
  }

  function featuredBadgeHtml(color) {
    return `<span class="forge-reviews__featured-badge" style="color:${color}"><svg viewBox="0 0 16 16" width="14" height="14" focusable="false" aria-hidden="true"><circle cx="8" cy="8" r="7.25" fill="currentColor"/><path d="M4.7 8.15 7 10.4l4.4-4.7" fill="none" stroke="#fff" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg></span>`;
  }

  function photosStripHtml(photos) {
    if (!Array.isArray(photos) || photos.length === 0) return "";
    const items = photos
      .map((p, idx) => {
        const thumb = p && (p.thumb_url || p.url);
        const full = p && (p.url || p.thumb_url);
        if (!thumb || !full) return "";
        return `<button
          type="button"
          class="forge-reviews__photo"
          data-action="open-photo"
          data-full="${escapeHtml(full)}"
          data-index="${idx}"
          aria-label="Open review photo ${idx + 1} of ${photos.length}"
        ><img src="${escapeHtml(thumb)}" alt="" loading="lazy" /></button>`;
      })
      .join("");
    return items ? `<div class="forge-reviews__photos">${items}</div>` : "";
  }

  function deriveTitleFromBody(body) {
    const trimmed = String(body ?? "")
      .trim()
      .replace(/\s+/g, " ");
    if (!trimmed) return "Customer review";
    const firstSentence = trimmed.split(/[.!?]\s/)[0];
    const candidate = firstSentence.length >= 3 ? firstSentence : trimmed;
    return candidate.slice(0, 80).trim() || "Customer review";
  }

  function emptyListPayload() {
    return {
      aggregate: { rating: 0, count: 0, distribution: {} },
      reviews: [],
      page: 1,
      per_page: 10,
      total: 0,
      submission_enabled: true,
    };
  }

  function normalizeListPayload(data) {
    if (!data || typeof data !== "object" || data.error) {
      return emptyListPayload();
    }
    const aggregate = data.aggregate || {};
    return {
      ...data,
      aggregate: {
        rating: Number(aggregate.rating) || 0,
        count: Number(aggregate.count) || 0,
        distribution: aggregate.distribution || {},
      },
      reviews: Array.isArray(data.reviews) ? data.reviews : [],
      total: Number(data.total) || 0,
      page: Number(data.page) || 1,
      per_page: Number(data.per_page) || 10,
    };
  }

  function formatRating(value) {
    const n = Number(value);
    if (!Number.isFinite(n) || n <= 0) return "0.0";
    return n.toFixed(1);
  }

  function initials(name) {
    const trimmed = String(name ?? "").trim();
    if (!trimmed) return "?";
    const parts = trimmed.split(/\s+/).filter(Boolean);
    const first = parts[0]?.[0] || "";
    const last = parts.length > 1 ? parts[parts.length - 1][0] : "";
    return (first + last).toUpperCase() || "?";
  }

  function formatReviewDate(iso, locale) {
    if (!iso) return "";
    const date = new Date(iso);
    if (Number.isNaN(date.getTime())) return "";
    try {
      return new Intl.DateTimeFormat(locale || undefined, {
        dateStyle: "medium",
      }).format(date);
    } catch {
      return "";
    }
  }

  // Sample data shown when a block has data-sample="1" (preview mode in the
  // theme editor). Keeps the storefront from ever rendering fake reviews to
  // real shoppers.
  const SAMPLE_AGGREGATE = { rating: 4.7, count: 128 };
  const SAMPLE_REVIEWS = [
    {
      rating: 5,
      title: "One jar, day and night",
      body: "One jar for day and night means one less step to think about. Makeup goes on over it without any pilling at all.",
      author_name: "Lena F.",
      country: "US",
      created_at: new Date(Date.now() - 3 * 86400000).toISOString(),
    },
    {
      rating: 5,
      title: "Worth every penny",
      body: "I was hesitant about the price but after using it for two weeks I have zero regrets. Highly recommend.",
      author_name: "Jonas K.",
      country: "DE",
      created_at: new Date(Date.now() - 9 * 86400000).toISOString(),
    },
    {
      rating: 4,
      title: "Great, with one small nitpick",
      body: "Love the look and feel. The only thing I wish was different is the color of the strap, but overall I am very happy.",
      author_name: "Sofia M.",
      country: "ES",
      created_at: new Date(Date.now() - 16 * 86400000).toISOString(),
    },
    {
      rating: 5,
      title: "Five stars from me",
      body: "Customer service was excellent when I had a question, and the product itself is even better than the photos.",
      author_name: "Marcus L.",
      country: "GB",
      created_at: new Date(Date.now() - 24 * 86400000).toISOString(),
    },
    {
      rating: 5,
      title: "Perfect",
      body: "Simple as that.",
      author_name: "Priya S.",
      country: "IN",
      created_at: new Date(Date.now() - 30 * 86400000).toISOString(),
    },
    {
      rating: 4,
      title: "Solid choice, a couple of caveats",
      body: "Been using this daily for about a month now. Build quality feels sturdy and it does exactly what it says on the tin. Setup took a little longer than expected because the instructions could be clearer, and I wish there were more color options, but once it was up and running I haven't had a single issue. Would still recommend to a friend.",
      author_name: "Noah T.",
      country: "CA",
      created_at: new Date(Date.now() - 38 * 86400000).toISOString(),
    },
  ];
  const SAMPLE_SUMMARY = {
    summary:
      "Customers love the build quality, packaging, and fast shipping. A few mention they would prefer more color options.",
    pros: [
      "Premium feel and finish",
      "Fast delivery",
      "Helpful customer service",
    ],
    cons: ["Limited color choices", "Slightly above average price"],
  };

  // Last-resort default if the snippet failed to render anything. The real URL is baked into
  // `snippets/forge-reviews-api-base.liquid` at deploy time by `scripts/deploy-forge-extension.mjs`.
  const FORGE_REVIEWS_DEFAULT_API_BASE =
    "https://forge-prod-11402474925.us-central1.run.app";
  // Shopify wraps rendered *app* snippet output in HTML comments when blocks use
  // {% capture %}{% render 'forge-reviews-api-base' %}. Prefer inline assign in Liquid;
  // this still sanitizes legacy themes and older data-api-base values.
  const HTML_COMMENT_PATTERN = /<!--[\s\S]*?-->/g;
  const ABSOLUTE_URL_PATTERN = /https?:\/\/[^\s<>"']+/i;

  function cleanUrl(raw) {
    return String(raw ?? "")
      .replace(HTML_COMMENT_PATTERN, "")
      .trim()
      .replace(/\/$/, "");
  }

  function resolveApiBase(raw) {
    const cleaned = cleanUrl(raw);
    const match = cleaned.match(ABSOLUTE_URL_PATTERN);
    if (match) return match[0].replace(/\/$/, "");
    if (/^https?:\/\//i.test(cleaned)) return cleaned;
    return FORGE_REVIEWS_DEFAULT_API_BASE;
  }

  // Reads the theme's live accent color so star/badge colors track future
  // Style-panel changes instead of a value baked in at generation time.
  function themeAccentColor(el, fallback) {
    const value = getComputedStyle(el).getPropertyValue("--color-primary").trim();
    return value || fallback;
  }

  class ForgeReviews extends HTMLElement {
    connectedCallback() {
      this.apiBase = resolveApiBase(this.dataset.apiBase);
      this.shop = this.dataset.shop || "";
      this.product = this.dataset.product || "";
      this.productImage = this.dataset.productImage || "";
      this.productTitle = this.dataset.productTitle || "";
      this.locale = document.documentElement.lang || "en";
      this.mode = this.dataset.mode || "box";
      this.perPage = Number(this.dataset.perPage || 10);
      this.starsColor =
        this.dataset.starsColor || themeAccentColor(this, "#f5a623");
      this.starsSize = ["small", "medium", "large"].includes(
        this.dataset.starsSize,
      )
        ? this.dataset.starsSize
        : "medium";
      this.cardBg = (this.dataset.cardBg || "").trim();
      this.cardBorderColor = (this.dataset.cardBorderColor || "").trim();
      this.layout = ["cards", "stacked", "list", "carousel"].includes(
        this.dataset.layout,
      )
        ? this.dataset.layout
        : "cards";
      this.autoplay = this.dataset.autoplay === "1";
      this.alignment = ["left", "center", "right"].includes(
        this.dataset.alignment,
      )
        ? this.dataset.alignment
        : "center";
      // Pagination is shown by default; merchants can disable it via the
      // section/block setting which sets data-show-pagination="0".
      this.showPagination = this.dataset.showPagination !== "0";
      this.showCount = this.dataset.showCount !== "0";
      this.showDate = this.dataset.showDate !== "0";
      this.formWidth = ["narrow", "medium", "wide"].includes(
        this.dataset.formWidth,
      )
        ? this.dataset.formWidth
        : "wide";
      // AI summary block options (only consulted in mode="summary"). All
      // optional - sensible defaults preserve the previous behaviour for
      // older Liquid templates that don't emit these attributes.
      this.summaryHeading = this.dataset.summaryHeading; // string or undefined
      this.summaryHeadingSize = ["small", "medium", "large"].includes(
        this.dataset.summaryHeadingSize,
      )
        ? this.dataset.summaryHeadingSize
        : "medium";
      this.summaryShowBadge = this.dataset.summaryShowBadge !== "0";
      this.summaryShowPros = this.dataset.summaryShowPros !== "0";
      this.summaryShowCons = this.dataset.summaryShowCons !== "0";
      this.summaryLayout =
        this.dataset.summaryLayout === "stacked" ? "stacked" : "side-by-side";
      this.summaryCardStyle =
        this.dataset.summaryCardStyle === "plain" ? "plain" : "card";
      this.summaryAccentColor =
        this.dataset.summaryAccentColor || this.starsColor || "#f5a623";
      this.sample = this.dataset.sample === "1";
      this.i18n = this.readI18n();
      // Optional rich-text snippet rendered next to the stars in mode="stars".
      // Sourced from a <template> child so Shopify's sanitised richtext HTML
      // survives the host element's innerHTML reset.
      this.starsInlineTextHtml = this.readStarsInlineText();
      void this.init();
    }

    readStarsInlineText() {
      const tmpl = this.querySelector(
        "template.forge-reviews__stars-inline-text",
      );
      return tmpl ? tmpl.innerHTML.trim() : "";
    }

    applyBoxThemeVars() {
      const STAR_SIZES = {
        small: "calc(0.95 * var(--forge-rem, 16px))",
        medium: "calc(1.15 * var(--forge-rem, 16px))",
        large: "calc(1.4 * var(--forge-rem, 16px))",
      };
      this.style.setProperty(
        "--forge-stars-size",
        STAR_SIZES[this.starsSize] || STAR_SIZES.medium,
      );
      this.style.setProperty("--forge-stars-color", this.starsColor);
    }

    readI18n() {
      const script = this.querySelector(
        'script[type="application/json"].forge-reviews__i18n',
      );
      let overrides = {};
      if (script) {
        try {
          overrides = JSON.parse(script.textContent || "{}") || {};
        } catch {
          overrides = {};
        }
      }
      return {
        ...I18N_DEFAULTS,
        ...overrides,
        ratingLabels: {
          ...I18N_DEFAULTS.ratingLabels,
          ...overrides.ratingLabels,
        },
        submitErrors: {
          ...I18N_DEFAULTS.submitErrors,
          ...overrides.submitErrors,
        },
      };
    }

    async init() {
      try {
        if (this.mode === "summary") {
          await this.renderSummary();
          return;
        }
        if (this.mode === "featured") {
          await this.renderFeatured();
          return;
        }
        if (this.mode === "stars") {
          this.renderStars();
          return;
        }
        if (this.mode === "form") {
          this.renderInlineForm();
          return;
        }
        await this.renderBox();
      } catch (err) {
        console.error("[forge-reviews] init failed", this.mode, err);
        if (this.mode === "box") {
          await this.renderBoxWithData(emptyListPayload());
        }
      }
    }

    renderStars() {
      let rating = Number(this.dataset.rating || 0);
      let count = Number(this.dataset.count || 0);
      if (this.sample) {
        rating = SAMPLE_AGGREGATE.rating;
        count = SAMPLE_AGGREGATE.count;
      }
      const inlineText = this.starsInlineTextHtml
        ? `<span class="forge-reviews__stars-inline">${this.starsInlineTextHtml}</span>`
        : "";
      this.innerHTML = `<div class="forge-reviews__stars">${starsHtml(rating, this.starsColor)} <span class="forge-reviews__count">(${count})</span>${inlineText}</div>`;
    }

    async renderFeatured() {
      this.featuredIndex = 0;
      this.featuredUserStopped = false;
      this.featuredLoop = this.dataset.loop === "1";
      this.featuredControls = ["none", "arrows", "dots"].includes(
        this.dataset.controls,
      )
        ? this.dataset.controls
        : "arrows";
      this.featuredAutoplay = this.dataset.autoplay === "1";
      this.featuredAutoplaySpeed = Math.max(
        1,
        Number(this.dataset.autoplaySpeed || 5),
      );
      this.featuredBadgeColor =
        this.dataset.badgeColor || this.starsColor || "#B06F78";
      this.featuredStarColor =
        this.dataset.starColor || this.starsColor || "#B06F78";
      this.featuredEmptyStarColor = this.dataset.emptyStarColor || "#EBD5D1";
      this.perPage = 5;

      const data = this.sample
        ? { reviews: SAMPLE_REVIEWS.slice(0, 5) }
        : normalizeListPayload(await this.fetchPage(1));
      const reviews = (data.reviews || []).slice(0, 5);
      if (!reviews.length) {
        this.innerHTML = "";
        return;
      }
      this.featuredReviews = reviews;
      this.innerHTML = this.featuredMarkup();
      this.wireFeatured();
    }

    featuredMarkup() {
      const reviews = this.featuredReviews;
      const total = reviews.length;
      const showArrows = this.featuredControls === "arrows" && total > 1;
      const showDots = this.featuredControls === "dots" && total > 1;
      const slideLabel =
        this.i18n.featuredSlideLabel || "Review {{ current }} of {{ total }}";
      const regionLabel = this.i18n.featuredLabel || "Customer reviews";
      const slides = reviews
        .map((r, i) => {
          const active = i === this.featuredIndex;
          return `<div class="forge-reviews__featured-slide${active ? " is-active" : ""}" role="group" aria-roledescription="slide" aria-label="${escapeHtml(fmt(slideLabel, { current: i + 1, total }))}" aria-hidden="${active ? "false" : "true"}">
            <div class="forge-reviews__featured-row">
              <span class="forge-reviews__featured-name">${escapeHtml(r.author_name || "")}</span>
              ${featuredBadgeHtml(this.featuredBadgeColor)}
              <span class="forge-reviews__featured-stars" aria-label="${escapeHtml(fmt(this.i18n.starsAriaLabel, { count: r.rating }))}">${featuredStarsHtml(r.rating, this.featuredStarColor, this.featuredEmptyStarColor)}</span>
            </div>
            <p class="forge-reviews__featured-text">${escapeHtml(r.body || "")}</p>
          </div>`;
        })
        .join("");

      const prevDisabled = !this.featuredLoop && this.featuredIndex === 0;
      const nextDisabled =
        !this.featuredLoop && this.featuredIndex === total - 1;
      const arrows = showArrows
        ? `<button type="button" class="forge-reviews__featured-nav forge-reviews__featured-nav--prev" data-action="featured-prev" aria-label="${escapeHtml(this.i18n.paginationPrevious)}"${prevDisabled ? " disabled" : ""}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 18 9 12 15 6"></polyline></svg>
          </button>
          <button type="button" class="forge-reviews__featured-nav forge-reviews__featured-nav--next" data-action="featured-next" aria-label="${escapeHtml(this.i18n.paginationNext)}"${nextDisabled ? " disabled" : ""}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 18 15 12 9 6"></polyline></svg>
          </button>`
        : "";

      const dots = showDots
        ? `<div class="forge-reviews__featured-dots" role="tablist" aria-label="${escapeHtml(regionLabel)}">${reviews
            .map((_, i) => {
              const selected = i === this.featuredIndex;
              return `<button type="button" class="forge-reviews__featured-dot${selected ? " is-active" : ""}" data-action="featured-goto" data-index="${i}" aria-label="${escapeHtml(fmt(this.i18n.paginationGotoPage, { page: i + 1 }))}" aria-current="${selected ? "true" : "false"}"></button>`;
            })
            .join("")}</div>`
        : "";

      return `<div class="forge-reviews__featured" role="region" aria-roledescription="carousel" aria-label="${escapeHtml(regionLabel)}">
        ${this.sample ? '<div class="forge-reviews__sample-badge">Sample data</div>' : ""}
        <div class="forge-reviews__featured-frame">
          ${arrows}
          <div class="forge-reviews__featured-card" data-role="featured-live" aria-live="${this.featuredAutoplay ? "off" : "polite"}">
            ${slides}
          </div>
        </div>
        ${dots}
      </div>`;
    }

    featuredGoTo(index, fromUser) {
      const total = this.featuredReviews.length;
      if (!total) return;
      let next = index;
      if (this.featuredLoop) {
        next = ((index % total) + total) % total;
      } else {
        next = Math.max(0, Math.min(total - 1, index));
      }
      this.featuredIndex = next;
      this.querySelectorAll(".forge-reviews__featured-slide").forEach(
        (slide, i) => {
          const active = i === next;
          slide.classList.toggle("is-active", active);
          slide.setAttribute("aria-hidden", active ? "false" : "true");
        },
      );
      this.querySelectorAll(".forge-reviews__featured-dot").forEach(
        (dot, i) => {
          const active = i === next;
          dot.classList.toggle("is-active", active);
          dot.setAttribute("aria-current", active ? "true" : "false");
        },
      );
      const prevBtn = this.querySelector('[data-action="featured-prev"]');
      const nextBtn = this.querySelector('[data-action="featured-next"]');
      if (prevBtn) prevBtn.disabled = !this.featuredLoop && next === 0;
      if (nextBtn) nextBtn.disabled = !this.featuredLoop && next === total - 1;
      if (fromUser) {
        this.featuredUserStopped = true;
        this.featuredStopAutoplay();
      }
    }

    featuredStopAutoplay() {
      if (this._featuredTimer) {
        clearInterval(this._featuredTimer);
        this._featuredTimer = null;
      }
    }

    featuredStartAutoplay() {
      this.featuredStopAutoplay();
      if (
        !this.featuredAutoplay ||
        this.featuredUserStopped ||
        this.featuredReviews.length < 2
      ) {
        return;
      }
      if (
        window.matchMedia &&
        window.matchMedia("(prefers-reduced-motion: reduce)").matches
      ) {
        return;
      }
      this._featuredTimer = setInterval(() => {
        if (
          !this.featuredLoop &&
          this.featuredIndex >= this.featuredReviews.length - 1
        ) {
          this.featuredStopAutoplay();
          return;
        }
        this.featuredGoTo(this.featuredIndex + 1, false);
      }, this.featuredAutoplaySpeed * 1000);
    }

    wireFeatured() {
      if (this._featuredWired) return;
      this._featuredWired = true;
      this.addEventListener("click", (event) => {
        const prev = event.target.closest('[data-action="featured-prev"]');
        if (prev) {
          this.featuredGoTo(this.featuredIndex - 1, true);
          return;
        }
        const next = event.target.closest('[data-action="featured-next"]');
        if (next) {
          this.featuredGoTo(this.featuredIndex + 1, true);
          return;
        }
        const dot = event.target.closest('[data-action="featured-goto"]');
        if (dot) {
          this.featuredGoTo(Number(dot.dataset.index), true);
        }
      });

      this.addEventListener("keydown", (event) => {
        if (event.key === "ArrowLeft") {
          event.preventDefault();
          this.featuredGoTo(this.featuredIndex - 1, true);
        } else if (event.key === "ArrowRight") {
          event.preventDefault();
          this.featuredGoTo(this.featuredIndex + 1, true);
        }
      });

      let touchStartX = 0;
      this.addEventListener(
        "touchstart",
        (event) => {
          touchStartX = event.changedTouches[0]?.clientX || 0;
        },
        { passive: true },
      );
      this.addEventListener(
        "touchend",
        (event) => {
          const dx = (event.changedTouches[0]?.clientX || 0) - touchStartX;
          if (Math.abs(dx) < 40) return;
          this.featuredGoTo(this.featuredIndex + (dx < 0 ? 1 : -1), true);
        },
        { passive: true },
      );

      this.addEventListener("mouseenter", () => this.featuredStopAutoplay());
      this.addEventListener("mouseleave", () => this.featuredStartAutoplay());
      this.addEventListener("focusin", () => this.featuredStopAutoplay());
      this.addEventListener("focusout", () => this.featuredStartAutoplay());
      this.featuredStartAutoplay();
    }

    async renderSummary() {
      if (this.sample) {
        this.renderSummaryFromData(SAMPLE_SUMMARY);
        return;
      }
      const url = `${this.apiBase}/api/reviews/summary?shop=${encodeURIComponent(this.shop)}&product=${encodeURIComponent(this.product)}&locale=${encodeURIComponent(this.locale)}`;
      const res = await fetch(url);
      if (res.status === 204) {
        this.innerHTML = "";
        return;
      }
      const data = await res.json();
      this.renderSummaryFromData(data);
    }

    renderSummaryFromData(data) {
      const i18n = this.i18n;
      const heading =
        this.summaryHeading !== undefined
          ? this.summaryHeading
          : i18n.summaryHeading;
      const hasHeading = heading && heading.trim().length > 0;

      const prosItems = this.summaryShowPros ? data.pros || [] : [];
      const consItems = this.summaryShowCons ? data.cons || [] : [];

      const prosBlock = prosItems.length
        ? `<div class="forge-reviews__summary-list forge-reviews__summary-list--pros">
            <h4 class="forge-reviews__summary-list-heading">${escapeHtml(i18n.summaryProsHeading)}</h4>
            <ul>${prosItems.map((p) => `<li>${escapeHtml(p)}</li>`).join("")}</ul>
          </div>`
        : "";

      const consBlock = consItems.length
        ? `<div class="forge-reviews__summary-list forge-reviews__summary-list--cons">
            <h4 class="forge-reviews__summary-list-heading">${escapeHtml(i18n.summaryConsHeading)}</h4>
            <ul>${consItems.map((c) => `<li>${escapeHtml(c)}</li>`).join("")}</ul>
          </div>`
        : "";

      const lists =
        prosBlock || consBlock
          ? `<div class="forge-reviews__summary-grid">${prosBlock}${consBlock}</div>`
          : "";

      const badge = this.summaryShowBadge
        ? `<div class="forge-reviews__summary-badge" aria-label="${escapeHtml(i18n.summaryAiBadge)}">
            <svg class="forge-reviews__summary-badge-icon" viewBox="0 0 24 24" width="14" height="14" aria-hidden="true" focusable="false">
              <path fill="currentColor" d="M12 2.5l1.7 4.6 4.6 1.7-4.6 1.7-1.7 4.6-1.7-4.6L5.7 8.8l4.6-1.7L12 2.5zm6.5 11l.9 2.4 2.4.9-2.4.9-.9 2.4-.9-2.4-2.4-.9 2.4-.9.9-2.4zM5 14l.7 2 2 .7-2 .7L5 19.4 4.3 17.4l-2-.7 2-.7L5 14z"/>
            </svg>
            <span>${escapeHtml(i18n.summaryAiBadge)}</span>
          </div>`
        : "";

      const summaryText = data.summary
        ? `<p class="forge-reviews__summary-text">${escapeHtml(data.summary)}</p>`
        : "";

      this.style.setProperty(
        "--forge-reviews-summary-accent",
        this.summaryAccentColor,
      );

      const classes = [
        "forge-reviews__summary",
        `forge-reviews__summary--${this.summaryCardStyle}`,
        `forge-reviews__summary--${this.summaryLayout}`,
        `forge-reviews__summary--align-${this.alignment}`,
      ].join(" ");

      const headingTag = this.summaryHeadingSize === "large" ? "h2" : "h3";
      const headingMarkup = hasHeading
        ? `<${headingTag} class="forge-reviews__summary-heading forge-reviews__summary-heading--${this.summaryHeadingSize}">${escapeHtml(heading)}</${headingTag}>`
        : "";

      this.innerHTML = `
        <div class="${classes}">
          ${this.sample ? '<div class="forge-reviews__sample-badge">Sample data</div>' : ""}
          ${badge}
          ${headingMarkup}
          ${summaryText}
          ${lists}
        </div>`;
    }

    async renderBox() {
      this.currentPage = 1;
      const data = normalizeListPayload(await this.fetchPage(this.currentPage));
      await this.renderBoxWithData(data);
    }

    async renderBoxWithData(data) {
      this.applyBoxThemeVars();
      const aggregateRating = Number(data.aggregate?.rating) || 0;
      const aggregateCount = Number(data.aggregate?.count) || 0;
      // submission_enabled defaults to true if the API omits it (older
      // deploys); merchants in sample/preview mode always see the button.
      const submissionEnabled =
        this.sample || data.submission_enabled !== false;

      const addButton = submissionEnabled
        ? `<button type="button" class="forge-reviews__add-btn" data-action="open-form">
            <span aria-hidden="true">+</span> ${escapeHtml(this.i18n.addReview)}
          </button>`
        : "";

      const dialogMarkup = submissionEnabled
        ? `<dialog class="forge-reviews__dialog" aria-labelledby="forge-reviews-dialog-title">
            <div class="forge-reviews__dialog-inner">
              ${this.formMarkup({ inDialog: true })}
            </div>
          </dialog>`
        : "";

      this.innerHTML = `
        <div class="forge-reviews__box forge-reviews__box--align-${this.alignment} forge-reviews__box--layout-${this.layout}">
          ${this.sample ? '<div class="forge-reviews__sample-badge">Sample data - preview only, not visible on storefront</div>' : ""}
          <div class="forge-reviews__box-header">
            <div class="forge-reviews__aggregate">
              ${starsHtml(aggregateRating, this.starsColor)}
              <span class="forge-reviews__aggregate-score">${formatRating(aggregateRating)}</span>
              ${this.showCount ? `<span class="forge-reviews__aggregate-count">(${aggregateCount})</span>` : ""}
            </div>
            ${addButton}
          </div>
          <div class="forge-reviews__list-wrap forge-reviews__list-wrap--${this.layout}${this.layout === "list" && this.autoplay ? " forge-reviews__list-wrap--ticker" : ""}${(this.layout === "carousel" || this.layout === "cards") && this.autoplay ? " forge-reviews__list-wrap--autoplay" : ""}">
            ${
              this.layout === "carousel"
                ? `<button type="button" class="forge-reviews__carousel-arrow forge-reviews__carousel-arrow--prev" data-action="carousel-prev" aria-label="${escapeHtml(this.i18n.paginationPrevious)}">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 18 9 12 15 6"></polyline></svg>
                  </button>`
                : ""
            }
            <div class="forge-reviews__list" data-role="list"></div>
            ${
              this.layout === "carousel"
                ? `<button type="button" class="forge-reviews__carousel-arrow forge-reviews__carousel-arrow--next" data-action="carousel-next" aria-label="${escapeHtml(this.i18n.paginationNext)}">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 18 15 12 9 6"></polyline></svg>
                  </button>`
                : ""
            }
          </div>
          <nav class="forge-reviews__pagination" data-role="pagination" aria-label="${escapeHtml(this.i18n.paginationNavLabel)}" hidden></nav>
        </div>
        <dialog class="forge-reviews__photo-dialog" data-role="photo-dialog" aria-label="Review photo">
          <button type="button" class="forge-reviews__photo-close" data-action="close-photo" aria-label="Close">×</button>
          <button type="button" class="forge-reviews__photo-nav forge-reviews__photo-nav--prev" data-action="prev-photo" aria-label="Previous photo" hidden>‹</button>
          <button type="button" class="forge-reviews__photo-nav forge-reviews__photo-nav--next" data-action="next-photo" aria-label="Next photo" hidden>›</button>
          <img class="forge-reviews__photo-img" data-role="photo-img" alt="" />
        </dialog>
        <dialog class="forge-reviews__text-dialog" data-role="text-dialog" aria-labelledby="forge-reviews-text-dialog-title">
          <button type="button" class="forge-reviews__text-dialog-close" data-action="close-text-dialog" aria-label="Close">×</button>
          <div class="forge-reviews__text-dialog-stars" data-role="text-dialog-stars"></div>
          <h3 id="forge-reviews-text-dialog-title" class="forge-reviews__text-dialog-title" data-role="text-dialog-title"></h3>
          <div class="forge-reviews__text-dialog-meta" data-role="text-dialog-meta"></div>
          <p class="forge-reviews__text-dialog-body" data-role="text-dialog-body"></p>
        </dialog>
        ${dialogMarkup}`;

      this.renderListAndPagination(data);
      this.wirePhotoLightbox();
      this.wireReviewTextDialog();
      if (this.layout === "carousel") this.wireCarousel();

      if (submissionEnabled) {
        const openBtn = this.querySelector('[data-action="open-form"]');
        const dialog = this.querySelector(".forge-reviews__dialog");
        if (openBtn && dialog) {
          openBtn.addEventListener("click", () => {
            if (typeof dialog.showModal === "function") {
              dialog.showModal();
            } else {
              dialog.setAttribute("open", "");
            }
          });
          dialog.addEventListener("click", (event) => {
            if (event.target === dialog) dialog.close();
          });
        }

        const cancelBtn = this.querySelector('[data-action="cancel"]');
        if (cancelBtn && dialog) {
          cancelBtn.addEventListener("click", () => dialog.close());
        }

        this.wireForm(this.querySelector("form.forge-reviews__form"));
      }
    }

    wireCarousel() {
      const listEl = this.querySelector('[data-role="list"]');
      const prevBtn = this.querySelector('[data-action="carousel-prev"]');
      const nextBtn = this.querySelector('[data-action="carousel-next"]');
      if (!listEl) return;

      const cardStep = () => {
        const item = listEl.querySelector(".forge-reviews__item");
        if (!item) return listEl.clientWidth;
        const style = getComputedStyle(listEl);
        const gap = parseFloat(style.columnGap || style.gap || "0") || 0;
        return item.getBoundingClientRect().width + gap;
      };
      const scrollByCards = (direction) => {
        listEl.scrollBy({ left: direction * cardStep(), behavior: "smooth" });
      };
      prevBtn?.addEventListener("click", () => {
        this.pauseAutoplay();
        scrollByCards(-1);
      });
      nextBtn?.addEventListener("click", () => {
        this.pauseAutoplay();
        scrollByCards(1);
      });
    }

    restartAutoplayIfNeeded() {
      this._autoplayStop?.();
      if (!this.autoplay) return;
      const listEl = this.querySelector('[data-role="list"]');
      if (!listEl) return;
      if (this.layout === "carousel" || this.layout === "cards") {
        this.startAutoplay(listEl, "x");
      } else if (this.layout === "list") {
        this.startAutoplay(listEl, "y");
      }
    }

    startAutoplay(listEl, axis) {
      if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
        return;
      }
      const items = listEl.querySelectorAll(".forge-reviews__item");
      const setSize = items.length / 2;
      if (!Number.isInteger(setSize) || setSize < 1) return;
      const isHorizontal = axis === "x";
      const posProp = isHorizontal ? "offsetLeft" : "offsetTop";
      const scrollProp = isHorizontal ? "scrollLeft" : "scrollTop";
      const resetPoint = items[setSize][posProp] - items[0][posProp];
      if (!(resetPoint > 0)) return;

      const PIXELS_PER_MS = isHorizontal ? 0.035 : 0.02;
      let paused = false;
      let lastT = null;
      let rafId = null;

      const step = (t) => {
        if (lastT === null) lastT = t;
        const dt = t - lastT;
        lastT = t;
        if (!paused && document.visibilityState === "visible") {
          listEl[scrollProp] += PIXELS_PER_MS * dt;
          if (listEl[scrollProp] >= resetPoint) {
            listEl[scrollProp] -= resetPoint;
          }
        }
        rafId = requestAnimationFrame(step);
      };
      rafId = requestAnimationFrame(step);

      this._autoplayPause = () => {
        paused = true;
      };
      this._autoplayResume = () => {
        paused = false;
        lastT = null;
      };
      this._autoplayStop = () => {
        if (rafId) cancelAnimationFrame(rafId);
      };

      listEl.addEventListener("mouseenter", this._autoplayPause);
      listEl.addEventListener("mouseleave", this._autoplayResume);
      listEl.addEventListener("touchstart", this._autoplayPause, {
        passive: true,
      });
      listEl.addEventListener("touchend", () => this.pauseAutoplay());
      listEl.addEventListener("focusin", this._autoplayPause);
      listEl.addEventListener("focusout", this._autoplayResume);
    }

    pauseAutoplay() {
      if (!this._autoplayPause) return;
      this._autoplayPause();
      clearTimeout(this._autoplayResumeTimer);
      this._autoplayResumeTimer = setTimeout(() => {
        this._autoplayResume?.();
      }, 2500);
    }

    wirePhotoLightbox() {
      const listEl = this.querySelector('[data-role="list"]');
      const dialog = this.querySelector('[data-role="photo-dialog"]');
      if (!listEl || !dialog) return;

      listEl.addEventListener("click", (event) => {
        const btn = event.target.closest('[data-action="open-photo"]');
        if (!btn || !listEl.contains(btn)) return;
        const strip = btn.closest(".forge-reviews__photos");
        if (!strip) return;
        const buttons = Array.from(
          strip.querySelectorAll('[data-action="open-photo"]'),
        );
        this._photoUrls = buttons.map((b) => b.dataset.full).filter(Boolean);
        const idx = buttons.indexOf(btn);
        this.showPhotoAt(idx >= 0 ? idx : 0);
        if (typeof dialog.showModal === "function") {
          dialog.showModal();
        } else {
          dialog.setAttribute("open", "");
        }
      });

      dialog.addEventListener("click", (event) => {
        if (event.target === dialog) dialog.close();
      });

      const closeBtn = dialog.querySelector('[data-action="close-photo"]');
      if (closeBtn) closeBtn.addEventListener("click", () => dialog.close());

      const prevBtn = dialog.querySelector('[data-action="prev-photo"]');
      const nextBtn = dialog.querySelector('[data-action="next-photo"]');
      if (prevBtn)
        prevBtn.addEventListener("click", () =>
          this.showPhotoAt((this._photoIndex ?? 0) - 1),
        );
      if (nextBtn)
        nextBtn.addEventListener("click", () =>
          this.showPhotoAt((this._photoIndex ?? 0) + 1),
        );

      dialog.addEventListener("keydown", (event) => {
        if (event.key === "ArrowLeft")
          this.showPhotoAt((this._photoIndex ?? 0) - 1);
        else if (event.key === "ArrowRight")
          this.showPhotoAt((this._photoIndex ?? 0) + 1);
      });
    }

    wireReviewTextDialog() {
      const listEl = this.querySelector('[data-role="list"]');
      const dialog = this.querySelector('[data-role="text-dialog"]');
      if (!listEl || !dialog) return;

      listEl.addEventListener("click", (event) => {
        const btn = event.target.closest('[data-action="read-more"]');
        if (!btn || !listEl.contains(btn)) return;
        const article = btn.closest(".forge-reviews__item");
        const reviews = this._lastReviewsData || [];
        const idx = article ? Number(article.dataset.reviewIdx) : NaN;
        const r =
          reviews[((idx % reviews.length) + reviews.length) % reviews.length];
        if (!r) return;

        const titleEl = dialog.querySelector('[data-role="text-dialog-title"]');
        const bodyEl = dialog.querySelector('[data-role="text-dialog-body"]');
        const metaEl = dialog.querySelector('[data-role="text-dialog-meta"]');
        const starsEl = dialog.querySelector('[data-role="text-dialog-stars"]');
        if (titleEl) titleEl.textContent = r.title || "";
        if (bodyEl) bodyEl.textContent = r.body || "";
        if (starsEl) starsEl.innerHTML = starsHtml(r.rating, this.starsColor);
        if (metaEl) {
          const meta = [r.author_name || ""];
          if (r.country) meta.push(r.country);
          const dateLabel = this.showDate
            ? formatReviewDate(r.created_at, this.locale)
            : "";
          if (dateLabel) meta.push(dateLabel);
          metaEl.textContent = meta.filter(Boolean).join(" · ");
        }

        if (typeof dialog.showModal === "function") {
          dialog.showModal();
        } else {
          dialog.setAttribute("open", "");
        }
      });

      dialog.addEventListener("click", (event) => {
        if (event.target === dialog) dialog.close();
      });

      const closeBtn = dialog.querySelector(
        '[data-action="close-text-dialog"]',
      );
      if (closeBtn) closeBtn.addEventListener("click", () => dialog.close());
    }

    showPhotoAt(index) {
      const urls = this._photoUrls || [];
      if (!urls.length) return;
      const wrapped = ((index % urls.length) + urls.length) % urls.length;
      this._photoIndex = wrapped;
      const img = this.querySelector('[data-role="photo-img"]');
      if (img) img.src = urls[wrapped];
      const prevBtn = this.querySelector('[data-action="prev-photo"]');
      const nextBtn = this.querySelector('[data-action="next-photo"]');
      const showNav = urls.length > 1;
      if (prevBtn) prevBtn.hidden = !showNav;
      if (nextBtn) nextBtn.hidden = !showNav;
    }

    async fetchPage(page) {
      if (this.sample) {
        return {
          aggregate: SAMPLE_AGGREGATE,
          reviews: SAMPLE_REVIEWS,
          page: 1,
          per_page: SAMPLE_REVIEWS.length,
          total: SAMPLE_REVIEWS.length,
        };
      }

      if (!this.apiBase || !this.shop || !this.product) {
        console.warn("[forge-reviews] missing apiBase, shop, or product", {
          apiBase: this.apiBase,
          shop: this.shop,
          product: this.product,
        });
        return emptyListPayload();
      }

      const listUrl = `${this.apiBase.replace(/\/$/, "")}/api/reviews/list?shop=${encodeURIComponent(this.shop)}&product=${encodeURIComponent(this.product)}&locale=${encodeURIComponent(this.locale)}&per_page=${this.perPage}&page=${page}`;

      try {
        const res = await fetch(listUrl);
        let data;
        try {
          data = await res.json();
        } catch (parseErr) {
          console.warn(
            "[forge-reviews] list response was not JSON",
            listUrl,
            parseErr,
          );
          return emptyListPayload();
        }
        if (!res.ok) {
          console.warn("[forge-reviews] list API error", res.status, data);
          return emptyListPayload();
        }
        return normalizeListPayload(data);
      } catch (err) {
        console.warn("[forge-reviews] list fetch failed", listUrl, err);
        return emptyListPayload();
      }
    }

    renderListAndPagination(data) {
      const listEl = this.querySelector('[data-role="list"]');
      const pagerEl = this.querySelector('[data-role="pagination"]');
      if (!listEl || !pagerEl) return;

      // Inline style on each item (same pattern stars use). This bypasses
      // CSS-variable inheritance that turned out unreliable in some hosts
      // and means the merchant-set values always win.
      const itemStyleParts = [];
      if (this.cardBg) itemStyleParts.push(`background-color:${this.cardBg}`);
      if (this.cardBorderColor) {
        itemStyleParts.push(`border-color:${this.cardBorderColor}`);
      }
      const isCarded = itemStyleParts.length > 0;
      const itemClass = isCarded
        ? "forge-reviews__item forge-reviews__item--carded"
        : "forge-reviews__item";
      const itemStyle = itemStyleParts.length
        ? ` style="${itemStyleParts.join(";")}"`
        : "";
      listEl.classList.toggle("forge-reviews__list--carded", isCarded);
      listEl.className = listEl.className.replace(
        /\bforge-reviews__list--layout-\S+/g,
        "",
      );
      listEl.classList.add(`forge-reviews__list--layout-${this.layout}`);

      const reviewsData = data.reviews || [];
      this._lastReviewsData = reviewsData;
      const itemsHtml = reviewsData
        .map((r, idx) => {
          const dateLabel = this.showDate
            ? formatReviewDate(r.created_at, this.locale)
            : "";
          const meta = [escapeHtml(r.author_name || "")];
          if (r.country) meta.push(escapeHtml(r.country));
          const metaLine = meta.filter(Boolean).join(" &middot; ");
          return `<article class="${itemClass}"${itemStyle} data-review-idx="${idx}">
            <header class="forge-reviews__item-header">
              <div class="forge-reviews__avatar" aria-hidden="true">${escapeHtml(initials(r.author_name))}</div>
              <div class="forge-reviews__item-identity">
                <span class="forge-reviews__item-name">${metaLine}</span>
                ${dateLabel ? `<span class="forge-reviews__item-date">${escapeHtml(dateLabel)}</span>` : ""}
              </div>
            </header>
            <div class="forge-reviews__item-stars">${starsHtml(r.rating, this.starsColor)}</div>
            <h4 class="forge-reviews__item-title">${escapeHtml(r.title)}</h4>
            <p class="forge-reviews__item-body">${escapeHtml(r.body)}</p>
            ${photosStripHtml(r.photos)}
          </article>`;
        })
        .join("");
      const emptyState = isCarded
        ? `<article class="${itemClass}"${itemStyle}>
            <p class="forge-reviews__empty">${escapeHtml(this.i18n.noReviewsYet)}</p>
          </article>`
        : `<p class="forge-reviews__empty">${escapeHtml(this.i18n.noReviewsYet)}</p>`;

      // Autoplay needs a second, identical copy of the row to loop seamlessly
      // (scroll position wraps back by exactly one set's size instead of
      // jumping). Stacked is the only layout that stays a plain full-height
      // page-flow wall regardless of the autoplay toggle.
      const isAutoplayScroll =
        this.autoplay &&
        (this.layout === "carousel" ||
          this.layout === "list" ||
          this.layout === "cards") &&
        reviewsData.length > 1;
      listEl.innerHTML = itemsHtml
        ? isAutoplayScroll
          ? itemsHtml + itemsHtml
          : itemsHtml
        : emptyState;
      listEl.classList.toggle(
        "forge-reviews__list--marquee",
        this.layout === "cards" && this.autoplay,
      );

      // Cards clamp the body to a fixed number of lines (carousel, and cards
      // in the autoplay/marquee variant) - only add a "read more" trigger
      // where that clamp is actually cutting text off, detected from real
      // layout rather than a brittle character-count guess.
      listEl.querySelectorAll(".forge-reviews__item-body").forEach((el) => {
        if (el.scrollHeight - el.clientHeight > 1) {
          const btn = document.createElement("button");
          btn.type = "button";
          btn.className = "forge-reviews__read-more";
          btn.dataset.action = "read-more";
          btn.textContent = this.i18n.readMore || "Read full review";
          el.insertAdjacentElement("afterend", btn);
        }
      });

      const total = Number(data.total ?? (data.reviews || []).length);
      const perPage = Number(data.per_page ?? this.perPage) || this.perPage;
      const totalPages = Math.max(1, Math.ceil(total / perPage));
      const current = Math.max(1, Number(data.page ?? this.currentPage));
      this.currentPage = current;

      const autoplayHidesPager =
        this.layout === "carousel" ||
        ((this.layout === "list" || this.layout === "cards") && this.autoplay);
      if (totalPages <= 1 || !this.showPagination || autoplayHidesPager) {
        pagerEl.hidden = true;
        pagerEl.innerHTML = "";
        this.restartAutoplayIfNeeded();
        return;
      }

      pagerEl.hidden = false;
      pagerEl.innerHTML = this.paginationMarkup(current, totalPages);

      pagerEl.querySelectorAll("[data-page]").forEach((btn) => {
        btn.addEventListener("click", (event) => {
          event.preventDefault();
          const next = Number(btn.getAttribute("data-page"));
          if (!Number.isFinite(next) || next === this.currentPage) return;
          void this.goToPage(next);
        });
      });

      this.restartAutoplayIfNeeded();
    }

    paginationMarkup(current, totalPages) {
      const i18n = this.i18n;
      const pageBtn = (n, isCurrent) => {
        const ariaLabel = fmt(i18n.paginationGotoPage, { page: n });
        return `<button
          type="button"
          class="forge-reviews__pagination-page${isCurrent ? " is-current" : ""}"
          data-page="${n}"
          aria-label="${escapeHtml(ariaLabel)}"
          ${isCurrent ? 'aria-current="page"' : ""}
        >${n}</button>`;
      };

      // Compute a compact window of page numbers around the current page so
      // we never render hundreds of buttons. Always show first/last; collapse
      // gaps with an ellipsis.
      const window = 1;
      const pages = new Set([1, totalPages, current]);
      for (let i = current - window; i <= current + window; i++) {
        if (i >= 1 && i <= totalPages) pages.add(i);
      }
      const sorted = [...pages].sort((a, b) => a - b);

      const items = [];
      sorted.forEach((p, idx) => {
        if (idx > 0 && p - sorted[idx - 1] > 1) {
          items.push(
            '<span class="forge-reviews__pagination-ellipsis" aria-hidden="true">…</span>',
          );
        }
        items.push(pageBtn(p, p === current));
      });

      const prevDisabled = current <= 1;
      const nextDisabled = current >= totalPages;

      return `
        <button
          type="button"
          class="forge-reviews__pagination-arrow"
          data-page="${current - 1}"
          ${prevDisabled ? "disabled" : ""}
        >${escapeHtml(i18n.paginationPrevious)}</button>
        <div class="forge-reviews__pagination-pages">${items.join("")}</div>
        <button
          type="button"
          class="forge-reviews__pagination-arrow"
          data-page="${current + 1}"
          ${nextDisabled ? "disabled" : ""}
        >${escapeHtml(i18n.paginationNext)}</button>`;
    }

    async goToPage(page) {
      const pagerEl = this.querySelector('[data-role="pagination"]');
      const listEl = this.querySelector('[data-role="list"]');
      if (listEl) listEl.setAttribute("aria-busy", "true");
      try {
        const data = await this.fetchPage(page);
        this.renderListAndPagination(data);
        const box = this.querySelector(".forge-reviews__box");
        if (box) {
          box.scrollIntoView({ behavior: "smooth", block: "start" });
        }
      } finally {
        if (listEl) listEl.removeAttribute("aria-busy");
        if (pagerEl) pagerEl.removeAttribute("aria-busy");
      }
    }

    renderInlineForm() {
      this.classList.add(`forge-reviews--form-width-${this.formWidth}`);
      this.innerHTML = this.formMarkup({ inDialog: false });
      this.wireForm(this.querySelector("form.forge-reviews__form"));
    }

    formMarkup({ inDialog }) {
      const i18n = this.i18n;
      const productImage = this.productImage
        ? `<img src="${escapeHtml(this.productImage)}" alt="${escapeHtml(this.productTitle || "Product")}" class="forge-reviews__form-product-image" />`
        : "";
      const ratingStars = [1, 2, 3, 4, 5]
        .map(
          (n) => `<button
            type="button"
            class="forge-reviews__rating-star"
            data-value="${n}"
            role="radio"
            aria-checked="${n === 5 ? "true" : "false"}"
            aria-label="${escapeHtml(fmt(i18n.starsAriaLabel, { count: n }))}"
            tabindex="${n === 5 ? "0" : "-1"}"
          >★</button>`,
        )
        .join("");
      const initialHint = fmt(i18n.minCharsHint, { count: BODY_MIN_CHARS });

      return `
        <form class="forge-reviews__form${inDialog ? " forge-reviews__form--dialog" : ""}" novalidate>
          ${this.sample ? '<div class="forge-reviews__sample-badge">Sample data - preview only</div>' : ""}
          ${inDialog ? `<h3 id="forge-reviews-dialog-title" class="forge-reviews__form-title">${escapeHtml(i18n.dialogTitle)}</h3>` : ""}

          <input type="hidden" name="hp_url" value="" tabindex="-1" autocomplete="off" />
          <input type="hidden" name="t_open" value="${Date.now()}" />
          <input type="hidden" name="form_token" value="" data-role="form-token" />
          <input type="hidden" name="rating" value="5" />
          <input type="hidden" name="title" value="" />

          <div class="forge-reviews__form-grid">
            <aside class="forge-reviews__form-product">
              ${productImage}
              <div
                class="forge-reviews__rating-picker"
                role="radiogroup"
                aria-label="${escapeHtml(i18n.yourRatingLabel)}"
                style="--forge-stars-color:${this.starsColor}"
              >
                ${ratingStars}
              </div>
              <div class="forge-reviews__rating-label" data-role="rating-label">${escapeHtml(i18n.ratingLabels[5])}</div>
            </aside>

            <div class="forge-reviews__form-fields">
              <label class="forge-reviews__field">
                <span class="forge-reviews__label">${escapeHtml(i18n.nameLabel)} <em aria-hidden="true">*</em></span>
                <input name="author_name" required placeholder="${escapeHtml(i18n.namePlaceholder)}" autocomplete="name" />
              </label>
              <label class="forge-reviews__field">
                <span class="forge-reviews__label">${escapeHtml(i18n.emailLabel)} <em aria-hidden="true">*</em></span>
                <input name="email" type="email" required placeholder="${escapeHtml(i18n.emailPlaceholder)}" autocomplete="email" />
              </label>
              <label class="forge-reviews__field forge-reviews__field--full">
                <span class="forge-reviews__label">${escapeHtml(i18n.feedbackLabel)} <em aria-hidden="true">*</em></span>
                <textarea name="body" required rows="5" placeholder="${escapeHtml(i18n.feedbackPlaceholder)}"></textarea>
              </label>

              <div class="forge-reviews__hint forge-reviews__field--full" data-role="hint">
                ${escapeHtml(initialHint)}
              </div>

              <label class="forge-reviews__dropzone forge-reviews__field--full">
                <input type="file" name="photos[]" accept="image/jpeg,image/png,image/gif" multiple />
                <div class="forge-reviews__dropzone-content">
                  <svg class="forge-reviews__dropzone-icon" viewBox="0 0 24 24" width="28" height="28" aria-hidden="true">
                    <path fill="currentColor" d="M12 5a7 7 0 0 0-6.91 5.86A4.5 4.5 0 0 0 6 19.5h11.5a4.5 4.5 0 0 0 .9-8.92A7 7 0 0 0 12 5Zm0 3.5 3.5 3.5h-2v3h-3v-3h-2L12 8.5Z" />
                  </svg>
                  <div class="forge-reviews__dropzone-text" data-role="dropzone-text">
                    ${escapeHtml(i18n.photosHint)}
                  </div>
                </div>
              </label>
            </div>
          </div>

          <p class="forge-reviews__message" role="status" hidden></p>

          <div class="forge-reviews__form-footer">
            ${inDialog ? `<button type="button" class="forge-reviews__btn forge-reviews__btn--ghost" data-action="cancel">${escapeHtml(i18n.cancel)}</button>` : ""}
            <button type="submit" class="forge-reviews__btn forge-reviews__btn--primary"${this.sample ? " disabled" : ""}>${escapeHtml(i18n.submit)}</button>
          </div>
        </form>`;
    }

    wireForm(form) {
      if (!form) return;
      const i18n = this.i18n;
      void this.ensureFormToken(form);

      const ratingInput = form.querySelector('input[name="rating"]');
      const ratingLabel = form.querySelector('[data-role="rating-label"]');
      const stars = Array.from(
        form.querySelectorAll(".forge-reviews__rating-star"),
      );
      const setRating = (value) => {
        ratingInput.value = String(value);
        stars.forEach((s) => {
          const v = Number(s.dataset.value);
          const active = v <= value;
          s.classList.toggle("is-filled", active);
          s.setAttribute("aria-checked", v === value ? "true" : "false");
          s.tabIndex = v === value ? 0 : -1;
        });
        if (ratingLabel)
          ratingLabel.textContent = i18n.ratingLabels[value] || "";
      };
      setRating(5);
      stars.forEach((star) => {
        star.addEventListener("click", () =>
          setRating(Number(star.dataset.value)),
        );
        star.addEventListener("keydown", (event) => {
          if (event.key === "ArrowRight" || event.key === "ArrowUp") {
            event.preventDefault();
            setRating(Math.min(5, Number(ratingInput.value) + 1));
            form
              .querySelector(
                `.forge-reviews__rating-star[data-value="${ratingInput.value}"]`,
              )
              ?.focus();
          } else if (event.key === "ArrowLeft" || event.key === "ArrowDown") {
            event.preventDefault();
            setRating(Math.max(1, Number(ratingInput.value) - 1));
            form
              .querySelector(
                `.forge-reviews__rating-star[data-value="${ratingInput.value}"]`,
              )
              ?.focus();
          }
        });
      });

      const body = form.querySelector('textarea[name="body"]');
      const hint = form.querySelector('[data-role="hint"]');
      const updateHint = () => {
        if (!hint) return;
        const len = body.value.trim().length;
        if (len >= BODY_MIN_CHARS) {
          hint.hidden = true;
        } else {
          hint.hidden = false;
          hint.textContent = fmt(i18n.minCharsHint, {
            count: BODY_MIN_CHARS - len,
          });
        }
      };
      body?.addEventListener("input", updateHint);
      updateHint();

      const fileInput = form.querySelector('input[type="file"]');
      const dropzoneText = form.querySelector('[data-role="dropzone-text"]');
      fileInput?.addEventListener("change", () => {
        if (!dropzoneText) return;
        const count = fileInput.files?.length || 0;
        dropzoneText.textContent = count
          ? fmt(i18n.photosSelected, { count })
          : i18n.photosHint;
      });

      form.addEventListener("submit", (event) => this.onSubmit(event, form));
    }

    async ensureFormToken(form) {
      if (this.sample || !this.apiBase || !this.shop || !this.product) return;
      const tokenInput = form.querySelector('[data-role="form-token"]');
      if (!tokenInput) return;
      try {
        const url = `${this.apiBase}/api/reviews/form-token?shop=${encodeURIComponent(this.shop)}&product=${encodeURIComponent(this.product)}`;
        const res = await fetch(url);
        if (!res.ok) return;
        const data = await res.json();
        if (data?.token) tokenInput.value = data.token;
      } catch {
        // fall back to t_open timing check on server
      }
    }

    async onSubmit(event, form) {
      event.preventDefault();
      if (this.sample) return;
      const i18n = this.i18n;

      const authorName = String(
        form.querySelector('[name="author_name"]')?.value ?? "",
      ).trim();
      const email = String(
        form.querySelector('[name="email"]')?.value ?? "",
      ).trim();
      const body = String(
        form.querySelector('[name="body"]')?.value ?? "",
      ).trim();

      // Form uses novalidate for custom messages — validate required fields here.
      if (!authorName) {
        this.showMessage(
          form,
          humanizeSubmitError(i18n, "name_required"),
          "error",
        );
        form.querySelector('[name="author_name"]')?.focus();
        return;
      }
      if (!email) {
        this.showMessage(
          form,
          humanizeSubmitError(i18n, "email_required"),
          "error",
        );
        form.querySelector('[name="email"]')?.focus();
        return;
      }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        this.showMessage(
          form,
          humanizeSubmitError(i18n, "email_invalid"),
          "error",
        );
        form.querySelector('[name="email"]')?.focus();
        return;
      }
      if (!body) {
        this.showMessage(
          form,
          humanizeSubmitError(i18n, "body_required"),
          "error",
        );
        form.querySelector('[name="body"]')?.focus();
        return;
      }
      if (body.length < BODY_MIN_CHARS) {
        this.showMessage(
          form,
          fmt(i18n.minCharsHint, { count: BODY_MIN_CHARS - body.length }),
          "error",
        );
        form.querySelector('[name="body"]')?.focus();
        return;
      }

      await this.ensureFormToken(form);

      const fd = new FormData(form);
      fd.set("author_name", authorName);
      fd.set("email", email);
      fd.set("body", body);
      fd.set("title", deriveTitleFromBody(body));
      fd.set("shop", this.shop);
      fd.set("product", this.product);
      fd.set("locale", this.locale);

      const submitBtn = form.querySelector('button[type="submit"]');
      if (submitBtn) submitBtn.disabled = true;

      try {
        const res = await fetch(`${this.apiBase}/api/reviews/submit`, {
          method: "POST",
          body: fd,
        });
        const data = await res.json();
        const isPending = res.ok && data.status === "pending";
        if (isPending) {
          form.reset();
          const ratingInput = form.querySelector('input[name="rating"]');
          if (ratingInput) ratingInput.value = "5";
          form.querySelectorAll(".forge-reviews__rating-star").forEach((s) => {
            s.classList.toggle("is-filled", Number(s.dataset.value) <= 5);
          });
          const hint = form.querySelector('[data-role="hint"]');
          if (hint) hint.hidden = false;
          void this.ensureFormToken(form);

          const dialog = form.closest(".forge-reviews__dialog");
          if (dialog) dialog.close();
          this.showToast(i18n.submitThanks);
        } else {
          this.showMessage(
            form,
            humanizeSubmitError(i18n, data.error),
            "error",
          );
        }
      } catch {
        this.showMessage(form, i18n.genericError, "error");
      } finally {
        if (submitBtn) submitBtn.disabled = false;
      }
    }

    showMessage(form, text, tone) {
      const msg = form.querySelector(".forge-reviews__message");
      if (!msg) return;
      msg.hidden = false;
      msg.textContent = text;
      msg.dataset.tone = tone;
      msg.setAttribute("role", tone === "error" ? "alert" : "status");
      msg.setAttribute("aria-live", tone === "error" ? "assertive" : "polite");
      try {
        msg.scrollIntoView({ block: "nearest", behavior: "smooth" });
      } catch {
        // ignore scroll failures in older browsers
      }
    }

    showToast(text) {
      const existing = this.querySelector(".forge-reviews__toast");
      if (existing) existing.remove();
      const toast = document.createElement("div");
      toast.className = "forge-reviews__toast";
      toast.setAttribute("role", "status");
      toast.setAttribute("aria-live", "polite");
      toast.innerHTML = `
        <svg class="forge-reviews__toast-icon" viewBox="0 0 20 20" width="18" height="18" aria-hidden="true" focusable="false">
          <path fill="currentColor" d="M7.629 13.233 4.4 10.004l-1.4 1.4 4.629 4.629 9-9-1.4-1.4z"/>
        </svg>
        <span>${escapeHtml(text)}</span>`;
      this.appendChild(toast);
      requestAnimationFrame(() => toast.classList.add("is-visible"));
      const remove = () => {
        toast.classList.remove("is-visible");
        toast.addEventListener("transitionend", () => toast.remove(), {
          once: true,
        });
      };
      toast.addEventListener("click", remove);
      setTimeout(remove, 4500);
    }
  }

  customElements.define("forge-reviews", ForgeReviews);
})();
